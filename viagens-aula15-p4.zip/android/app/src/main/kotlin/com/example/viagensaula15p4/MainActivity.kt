package com.example.viagensaula15p4

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
