import 'package:flutter/material.dart';

void main() {
  runApp(const UniViagens());
}

class UniViagens extends StatelessWidget {
  const UniViagens({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'UNI-VIAGENS',
      theme: ThemeData(
        primaryColor: const Color(0xFF1676C5),
        scaffoldBackgroundColor: Colors.white,
        useMaterial3: true,
      ),
      home: const TelaPrincipal(),
    );
  }
}

class TelaPrincipal extends StatefulWidget {
  const TelaPrincipal({super.key});

  @override
  State<TelaPrincipal> createState() => _TelaPrincipalState();
}

class _TelaPrincipalState extends State<TelaPrincipal> {
  final Color azul = const Color(0xFF1676C5);

  int? destinoSelecionado;
  int? pessoaSelecionada;

  bool carregando = true;
  double opacidade = 1;

  final List<Map<String, dynamic>> destinos = [
    {
      'nome': 'Coliseu',
      'cidade': 'Roma, Itália',
      'imagem': 'https://images.unsplash.com/photo-1552832230-c0197dd311b5',
      'descricao':
          'O Coliseu é um dos monumentos mais famosos da Itália e representa uma parte importante da história da Roma Antiga. Construído há quase dois mil anos, o local recebia grandes espetáculos públicos, incluindo combates entre gladiadores. Atualmente, é um dos principais pontos turísticos do mundo e recebe visitantes interessados em conhecer sua arquitetura e história.',
      'pessoas': [
        {
          'nome': 'Mariana Costa',
          'telefone': '+55 (11) 90000-0101',
          'foto': 'https://randomuser.me/api/portraits/women/44.jpg',
          'descricao':
              'Sou estudante de arquitetura e adoro conhecer construções históricas. Estou visitando Roma pela primeira vez e pretendo explorar outros monumentos da cidade. Gosto de fotografia, passeios culturais e conhecer pessoas durante minhas viagens.',
        },
        {
          'nome': 'Lucas Almeida',
          'telefone': '+55 (21) 90000-0102',
          'foto': 'https://randomuser.me/api/portraits/men/32.jpg',
          'descricao':
              'Trabalho com tecnologia e aproveito minhas férias para conhecer novos países. Tenho bastante interesse pela história romana e pela arquitetura antiga. Gosto de caminhar pela cidade e experimentar comidas típicas.',
        },
        {
          'nome': 'Beatriz Martins',
          'telefone': '+55 (31) 90000-0103',
          'foto': 'https://randomuser.me/api/portraits/women/68.jpg',
          'descricao':
              'Sou apaixonada por viagens, arte e cultura. Estou fazendo um roteiro pela Europa e Roma era uma das cidades que mais queria conhecer. Costumo registrar meus passeios com fotografias.',
        },
        {
          'nome': 'Rafael Oliveira',
          'telefone': '+55 (41) 90000-0104',
          'foto': 'https://randomuser.me/api/portraits/men/75.jpg',
          'descricao':
              'Gosto de conhecer lugares históricos e aprender sobre outras culturas. Estou viajando com amigos e aproveitando cada oportunidade para descobrir lugares diferentes. Também gosto de esportes e música.',
        },
      ],
    },
    {
      'nome': 'Cristo Redentor',
      'cidade': 'Rio de Janeiro, Brasil',
      'imagem': 'https://images.unsplash.com/photo-1483729558449-99ef09a8c325',
      'descricao':
          'O Cristo Redentor é um dos maiores símbolos do Brasil. Localizado no alto do Morro do Corcovado, no Rio de Janeiro, o monumento possui uma vista impressionante da cidade. Inaugurado em 1931, tornou-se uma das atrações turísticas mais conhecidas do país e recebe visitantes de diversas partes do mundo.',
      'pessoas': [
        {
          'nome': 'Camila Ferreira',
          'telefone': '+55 (81) 90000-0201',
          'foto': 'https://randomuser.me/api/portraits/women/22.jpg',
          'descricao':
              'Sou professora e adoro conhecer novos lugares pelo Brasil. Estou aproveitando alguns dias de folga no Rio de Janeiro. Gosto de praias, fotografia e passeios ao ar livre.',
        },
        {
          'nome': 'Pedro Henrique',
          'telefone': '+55 (85) 90000-0202',
          'foto': 'https://randomuser.me/api/portraits/men/46.jpg',
          'descricao':
              'Sou universitário e gosto bastante de viajar. Tenho interesse por paisagens naturais, história e cultura brasileira. Essa é minha primeira visita ao Cristo Redentor.',
        },
        {
          'nome': 'Isabela Rocha',
          'telefone': '+55 (71) 90000-0203',
          'foto': 'https://randomuser.me/api/portraits/women/53.jpg',
          'descricao':
              'Trabalho com design e gosto de buscar inspiração em lugares diferentes. O Rio de Janeiro sempre esteve na minha lista de viagens. Adoro música, arte e conhecer restaurantes locais.',
        },
        {
          'nome': 'Gabriel Santos',
          'telefone': '+55 (61) 90000-0204',
          'foto': 'https://randomuser.me/api/portraits/men/18.jpg',
          'descricao':
              'Sou fotógrafo amador e gosto de registrar paisagens e momentos especiais. Estou conhecendo os principais pontos turísticos do Rio e aproveitando para fazer muitas fotografias.',
        },
      ],
    },
    {
      'nome': 'Estátua da Liberdade',
      'cidade': 'Nova York, Estados Unidos',
      'imagem': 'https://images.unsplash.com/photo-1534430480872-3498386e7856',
      'descricao':
          'A Estátua da Liberdade é um dos monumentos mais conhecidos dos Estados Unidos. Localizada na entrada do porto de Nova York, ela representa liberdade e esperança. Inaugurada em 1886, foi um presente da França aos Estados Unidos e se tornou um importante símbolo histórico e cultural.',
      'pessoas': [
        {
          'nome': 'Amanda Ribeiro',
          'telefone': '+55 (11) 90000-0301',
          'foto': 'https://randomuser.me/api/portraits/women/12.jpg',
          'descricao':
              'Sou estudante de relações internacionais e tenho muito interesse pela história dos Estados Unidos. Estou conhecendo Nova York durante minhas férias e visitando os principais pontos turísticos.',
        },
        {
          'nome': 'Matheus Lima',
          'telefone': '+55 (21) 90000-0302',
          'foto': 'https://randomuser.me/api/portraits/men/52.jpg',
          'descricao':
              'Trabalho com programação e gosto de conhecer cidades grandes e movimentadas. Nova York sempre foi um destino dos meus sonhos. Gosto de tecnologia, cinema e gastronomia.',
        },
        {
          'nome': 'Sofia Carvalho',
          'telefone': '+55 (31) 90000-0303',
          'foto': 'https://randomuser.me/api/portraits/women/31.jpg',
          'descricao':
              'Sou estudante de comunicação e adoro conhecer culturas diferentes. Estou fazendo uma viagem internacional e aproveitando para visitar museus, monumentos e lugares famosos da cidade.',
        },
        {
          'nome': 'Bruno Mendes',
          'telefone': '+55 (51) 90000-0304',
          'foto': 'https://randomuser.me/api/portraits/men/64.jpg',
          'descricao':
              'Sou apaixonado por esportes, viagens e fotografia. Estou conhecendo Nova York pela primeira vez e quero aproveitar para explorar também os bairros menos conhecidos da cidade.',
        },
      ],
    },
  ];

  @override
  void initState() {
    super.initState();
    iniciarCarregamento();
  }

  Future<void> iniciarCarregamento() async {
    await Future.delayed(const Duration(milliseconds: 350));

    if (!mounted) return;

    setState(() {
      opacidade = 0;
    });

    await Future.delayed(const Duration(milliseconds: 650));

    if (!mounted) return;

    setState(() {
      carregando = false;
    });
  }

  Future<void> trocarTela(int? destino, {int? pessoa}) async {
    if (carregando) return;

    setState(() {
      carregando = true;
      opacidade = 1;
    });

    setState(() {
      destinoSelecionado = destino;
      pessoaSelecionada = pessoa;
    });

    await iniciarCarregamento();
  }

  void voltarTela() {
    if (pessoaSelecionada != null) {
      trocarTela(destinoSelecionado);
    } else {
      trocarTela(null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          appBar: AppBar(
            backgroundColor: azul,
            foregroundColor: Colors.white,
            elevation: 0,
            leading: destinoSelecionado == null
                ? null
                : IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: voltarTela,
                  ),
            title: const Text(
              'Viagens',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          body: destinoSelecionado == null
              ? telaInicial()
              : pessoaSelecionada != null
                  ? telaPessoa(
                      destinos[destinoSelecionado!]['pessoas']
                          [pessoaSelecionada!],
                    )
                  : telaDestino(
                      destinos[destinoSelecionado!],
                      destinoSelecionado!,
                    ),
        ),
        if (carregando)
          Positioned.fill(
            child: AnimatedOpacity(
              opacity: opacidade,
              duration: const Duration(milliseconds: 650),
              curve: Curves.easeOut,
              child: Container(
                color: Colors.white,
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'UNI-VIAGENS',
                        style: TextStyle(
                          color: Color(0xFF1676C5),
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 25),
                      SizedBox(
                        width: 170,
                        child: LinearProgressIndicator(
                          backgroundColor: Colors.blue.shade100,
                          color: Color(0xFF1676C5),
                          minHeight: 5,
                        ),
                      ),
                      const SizedBox(height: 15),
                      Text(
                        'Preparando sua viagem...',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget telaInicial() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Explore o mundo',
            style: TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            'Escolha seu próximo destino.',
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 22),
          for (int i = 0; i < destinos.length; i++)
            GestureDetector(
              onTap: () => trocarTela(i),
              child: Container(
                height: 190,
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.15),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      imagemDestino(destinos[i]['imagem']),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.75),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 16,
                        bottom: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              destinos[i]['nome'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 23,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(
                                    color: Colors.black,
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              destinos[i]['cidade'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                shadows: [
                                  Shadow(
                                    color: Colors.black,
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Positioned(
                        right: 15,
                        bottom: 20,
                        child: Icon(
                          Icons.arrow_forward_ios,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget telaDestino(Map<String, dynamic> destino, int indiceDestino) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 250,
            width: double.infinity,
            child: Stack(
              fit: StackFit.expand,
              children: [
                imagemDestino(destino['imagem']),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.75),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  left: 18,
                  bottom: 20,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        destino['cidade'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                      Text(
                        destino['nome'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 29,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              opcao(Icons.location_on_outlined, 'Quero Ir'),
              opcao(Icons.check_circle_outline, 'Já Fui'),
              opcao(Icons.share_outlined, 'Compartilhar'),
              opcao(Icons.star_border, 'Avaliações'),
            ],
          ),
          const SizedBox(height: 25),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Sobre o destino',
                  style: TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1676C5),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  destino['descricao'],
                  textAlign: TextAlign.justify,
                  style: const TextStyle(
                    fontSize: 15,
                    height: 1.6,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Pessoas Encontradas',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: null,
                      icon: const Icon(
                        Icons.filter_list,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                pessoasEncontradas(destino['pessoas'], indiceDestino),
                const SizedBox(height: 25),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget pessoasEncontradas(List<dynamic> pessoas, int indiceDestino) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        for (int i = 0; i < pessoas.length; i++)
          pessoa(pessoas[i]['nome'], indiceDestino, i),
      ],
    );
  }

  Widget pessoa(String nome, int destino, int indicePessoa) {
    return GestureDetector(
      onTap: () => trocarTela(
        destino,
        pessoa: indicePessoa,
      ),
      child: Column(
        children: [
          CircleAvatar(
            radius: 25,
            backgroundColor: Colors.blue.shade50,
            child: Icon(
              Icons.person,
              color: azul,
              size: 28,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            nome.split(' ').first,
            style: const TextStyle(
              fontSize: 10,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget telaPessoa(Map<String, String> pessoa) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 25),
          CircleAvatar(
            radius: 75,
            backgroundColor: Colors.blue.shade50,
            backgroundImage: NetworkImage(pessoa['foto']!),
          ),
          const SizedBox(height: 20),
          Text(
            pessoa['nome']!,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1676C5),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            pessoa['telefone']!,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 30),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Sobre mim',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1676C5),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  pessoa['descricao']!,
                  textAlign: TextAlign.justify,
                  style: const TextStyle(
                    fontSize: 15,
                    height: 1.7,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 25),
          Text(
            'Visitante do UNI-VIAGENS',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  Widget opcao(IconData icone, String nome) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icone,
          color: azul,
          size: 28,
        ),
        const SizedBox(height: 6),
        Text(
          nome,
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget imagemDestino(String url) {
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) {
        return Container(
          color: Colors.blue.shade100,
          child: const Center(
            child: Icon(
              Icons.image_not_supported_outlined,
              color: Colors.blue,
              size: 45,
            ),
          ),
        );
      },
    );
  }
}
